Thanks for downloading. 

Since this typeface is completely free for commercial and personal use, please appreciate it on behance (https://www.behance.net/gallery/51573445/Rostov-Free-Typeface) to reward my efforts put into it.

Also you can follow me on dribbble (https://dribbble.com/andyusikov), instagram (https://www.instagram.com/andyusikov) and behance(https://www.behance.net/usikov).

If you have any questions, ideas for collaborations or something else you can drop me an e-mail on andyusikov@gmail.com.

Also make sure you checked out amazing aerial shots of #77 (https://www.instagram.com/semdesiatsedmoy/)

Thanks a lot, have a nice day!